#!/bin/bash

./../../run_ncsim.bash -input ncsim.run -messages -cdslib ../../cds.lib -hdlvar ../../hdl.var "$@"

