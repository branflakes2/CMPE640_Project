#!/bin/bash

ghdl -a --ieee=synopsys $@
