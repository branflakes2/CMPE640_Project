#!/bin/bash

./../../run_ncsim.bash -gui -cdslib ../../cds.lib -hdlvar ../../hdl.var "$@"

