#!/bin/bash

./../../run_ncelab.bash -messages -access rwc -cdslib ../../cds.lib -hdlvar ../../hdl.var "$@"

