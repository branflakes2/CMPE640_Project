#!/bin/bash

ghdl -e --ieee=synopsys $@
