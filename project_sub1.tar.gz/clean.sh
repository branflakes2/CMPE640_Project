#!/bin/bash

rm *.o out.vcd *.cf *.swo *.swp *test
