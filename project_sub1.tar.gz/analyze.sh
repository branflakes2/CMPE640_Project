#!/bin/bash

./../../run_ncvhdl.bash -messages -linedebug -v93 -cdslib ../../cds.lib -hdlvar ../../hdl.var -smartorder "$@"

