#!/bin/bash

ghdl -r $1 --vcd=out.vcd
